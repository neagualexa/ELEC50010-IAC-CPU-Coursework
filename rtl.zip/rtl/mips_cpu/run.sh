iverilog -g 2012 -Wall -o CPU_testbench *.v used_in_test/*.v
